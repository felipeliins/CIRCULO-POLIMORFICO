public class LerEsferaCilindro {
    public static char lerTipo() throws Exception{
        char tipo;
        do{
            System.out.println("\nInforme 'E' para Esfera, 'C' para Cilindro ou 'F' para Fim->");
            tipo = JUtil.readChar();
        }while ((tipo != 'E') && (tipo != 'C') && (tipo != 'F'));
        return (tipo); 
    }

    public static void main(String[] args) throws Exception{
        Circulo ec;
        char tipo;
        tipo = lerTipo();
        while (tipo != 'F') {
            switch (tipo) {
                case 'E':
                    {ec = new Esfera(0);
                    System.out.println("Informe o raio: ");
                    ((Esfera)ec).setRaio(JUtil.readDouble());
                    break;}
                case 'C':
                    {ec = new Cilindro(0,0);
                    System.out.println("Informe o raio: ");
                    ((Cilindro)ec).setRaio(JUtil.readDouble());
                    System.out.println("Informe a Altura: ");
                    ((Cilindro)ec).setAltura(JUtil.readDouble());
                    break;}
                    default: ec = new Esfera(0);
            }
            if ( ec instanceof Circulo )
            {System.out.println ("\nDiametro Circulo " + ((Circulo) ec).diametro ());}
            ec.mostraDados();
            tipo = lerTipo ();	
        }
    }
}
