class Cilindro extends Circulo {
    private double altura;

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public Cilindro(double raio, double altura){
        super(raio);
        this.altura = altura;
    }
    
    public Cilindro(){
        super(0);
        this.altura = 0.0;
    }

    public double areaLateral(){
        return(super.perimetro() * this.altura);
    }

    @Override
    public double area() {
        return (2 * super.area() + this.areaLateral());
    }
    
    public double volume(){
        return(super.area() * this.altura);
    }

    @Override
    public void mostraDados(){
        System.out.println("Raio: " + super.getRaio());
        System.out.println("Area da Base: " + super.area());
        System.out.println("Perímetro: " + super.perimetro());
        System.out.println("Diâmetro: " + super.diametro());
        System.out.println("Area lateral: " + this.areaLateral());
        System.out.println("Area: " + this.area());
        System.out.println("Volume: " + this.volume());
    }
    
}
