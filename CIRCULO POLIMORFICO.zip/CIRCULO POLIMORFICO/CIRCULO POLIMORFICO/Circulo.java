abstract class Circulo {
    private double raio;

    public double getRaio() {
        return this.raio;
    }

    public void setRaio(double raio) {
        this.raio = raio;
    }

    public Circulo(double raio) {
        this.raio = raio;
    }

    public Circulo() {
        this.raio = 0.0;
    }

    public double diametro(){
        return(2*this.raio);
    }

    public double area(){
        return(Math.PI * Math.pow(this.raio, 2));
    }
    
    public double perimetro(){
        return(2 * Math.PI * this.raio);
    }

    public void mostraDados(){
        System.out.println("Raio: " + this.raio);
        System.out.println("Área: " + this.area());
        System.out.println("Perímetro: " + this.perimetro());
        System.out.println("Diâmetro: " + this.diametro());
    }
    
}