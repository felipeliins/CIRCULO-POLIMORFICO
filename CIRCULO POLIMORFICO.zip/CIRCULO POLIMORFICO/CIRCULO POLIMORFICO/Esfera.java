class Esfera extends Circulo{
    public Esfera(double raio){
        super(raio);
    }
    public Esfera(){
        super(0);
    }
    @Override
    public double area() {
        return (4 * super.area());
    }
    
    public double volume(){
        return(4/3 * Math.PI * Math.pow(getRaio(), 3));
    }
    
    @Override
    public void mostraDados(){
        System.out.println("Raio: " + super.getRaio());
        System.out.println("Área: " + this.area());
        System.out.println("Volume: " + this.volume());
    }
   
}
